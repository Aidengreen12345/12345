BUILD MART FLY  (Fabric server mod, Minecraft 1.21.8)  -- SERVER ONLY, players need no mod.

What it does
  Gives players vanilla creative-style flight while they are inside THEIR team's 50x50x50 fly box.
  Double-tap jump = fly, double-tap again = land, Space = up, Shift = down, WASD = move. The vanilla client does all the
  movement itself (momentum included), so it is perfectly smooth - no teleporting.
  Works in survival and adventure. Creative/spectator players are never touched.
  Leaving the box, being on no team, or gliding with the elytra removes the flight (fall damage is reset when it is removed).
  Team = score of the datapack's bm_team objective (1+). Needs no other connection to the datapack.

Install
  1. Put buildmartfly-1.0.0.jar and Fabric API in the server's mods folder (Fabric loader for 1.21.8).
  2. Start the server.

Commands (op level 2)
  /bmfly setcenter <team>   stand at the BOTTOM-center of the area; saves a 50x50x50 box (25 west/north, 24 east/south, 49 up)
  /bmfly remove <team>      /bmfly list      /bmfly clear
  /bmfly speed <value>      fly speed, default 0.0328 (vanilla creative 0.05 ~ 10.9 blocks/s horizontal).
                            Tune it until it feels like 7.16 blocks/s. Vertical speed is set by the client and scales with it.
  Boxes and speed are saved in config/buildmartfly.json.

Build
  Needs JDK 21 and internet:   gradle build      (or ./gradlew build)    -> build/libs/buildmartfly-1.0.0.jar
