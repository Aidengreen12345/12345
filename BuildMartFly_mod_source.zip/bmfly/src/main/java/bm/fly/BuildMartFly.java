package bm.fly;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.ReadOnlyScoreInfo;
import net.minecraft.world.scores.Scoreboard;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Gives vanilla creative-style flight (double-tap jump, space up, shift down, native momentum)
 * to team players while they stand inside their team's fly box. Runs on the server only; the
 * vanilla client does all the movement, so it is perfectly smooth.
 */
public class BuildMartFly implements ModInitializer {
    static class Box { int team, x1, y1, z1, x2, y2, z2; }
    static class Config {
        List<Box> boxes = new ArrayList<>();
        float flySpeed = 0.0328f;      // vanilla creative default is 0.05
        String teamObjective = "bm_team";
        boolean requireTeam = true;
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final Set<UUID> granted = new HashSet<>();
    private Config cfg = new Config();
    private Path file;

    @Override
    public void onInitialize() {
        file = FabricLoader.getInstance().getConfigDir().resolve("buildmartfly.json");
        load();
        ServerTickEvents.END_SERVER_TICK.register(this::tick);
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> {
            for (ServerPlayer p : new ArrayList<>(s.getPlayerList().getPlayers())) revoke(p);
        });
        CommandRegistrationCallback.EVENT.register((d, ra, env) -> {
            d.register(Commands.literal("bmfly").requires(s -> s.hasPermission(2))
                .then(Commands.literal("setcenter").then(Commands.argument("team", IntegerArgumentType.integer(1))
                    .executes(c -> setCenter(c.getSource(), IntegerArgumentType.getInteger(c, "team")))))
                .then(Commands.literal("remove").then(Commands.argument("team", IntegerArgumentType.integer(1))
                    .executes(c -> remove(c.getSource(), IntegerArgumentType.getInteger(c, "team")))))
                .then(Commands.literal("clear").executes(c -> { cfg.boxes.clear(); save(); msg(c.getSource(), "All fly boxes removed."); return 1; }))
                .then(Commands.literal("list").executes(c -> list(c.getSource())))
                .then(Commands.literal("speed").then(Commands.argument("value", FloatArgumentType.floatArg(0.005f, 0.2f))
                    .executes(c -> { cfg.flySpeed = FloatArgumentType.getFloat(c, "value"); save();
                        msg(c.getSource(), "Fly speed set to " + cfg.flySpeed + " (vanilla creative = 0.05)."); return 1; }))));
        });
    }

    private int setCenter(CommandSourceStack src, int team) {
        ServerPlayer p = src.getPlayer();
        if (p == null) { msg(src, "Run this as a player (stand at the bottom-center)."); return 0; }
        cfg.boxes.removeIf(b -> b.team == team);
        Box b = new Box();
        b.team = team;
        int cx = p.getBlockX(), cy = p.getBlockY(), cz = p.getBlockZ();
        b.x1 = cx - 25; b.x2 = cx + 24;
        b.y1 = cy;      b.y2 = cy + 49;
        b.z1 = cz - 25; b.z2 = cz + 24;
        cfg.boxes.add(b);
        save();
        msg(src, "Team " + team + " fly box saved: 50x50x50 centered on you, from your feet up.");
        return 1;
    }

    private int remove(CommandSourceStack src, int team) {
        boolean r = cfg.boxes.removeIf(b -> b.team == team);
        save();
        msg(src, r ? "Removed team " + team + " fly box." : "Team " + team + " has no fly box.");
        return r ? 1 : 0;
    }

    private int list(CommandSourceStack src) {
        if (cfg.boxes.isEmpty()) msg(src, "No fly boxes set.");
        for (Box b : cfg.boxes)
            msg(src, "Team " + b.team + ": " + b.x1 + " " + b.y1 + " " + b.z1 + "  ->  " + b.x2 + " " + b.y2 + " " + b.z2);
        return cfg.boxes.size();
    }

    private static void msg(CommandSourceStack s, String t) {
        s.sendSuccess(() -> Component.literal("[Build Mart Fly] " + t), false);
    }

    private int teamOf(MinecraftServer server, ServerPlayer p) {
        Scoreboard sb = server.getScoreboard();
        Objective o = sb.getObjective(cfg.teamObjective);
        if (o == null) return 0;
        ReadOnlyScoreInfo info = sb.getPlayerScoreInfo(p, o);
        return info == null ? 0 : info.value();
    }

    private boolean allowed(MinecraftServer server, ServerPlayer p) {
        int team = teamOf(server, p);
        if (team <= 0) return false;
        int x = p.getBlockX(), y = p.getBlockY(), z = p.getBlockZ();
        for (Box b : cfg.boxes)
            if (b.team == team && x >= b.x1 && x <= b.x2 && y >= b.y1 && y <= b.y2 && z >= b.z1 && z <= b.z2) return true;
        return false;
    }

    private void tick(MinecraftServer server) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            // Creative and spectator already have their own flight; never touch them.
            if (p.isCreative() || p.isSpectator()) { granted.remove(p.getUUID()); continue; }
            boolean ok = allowed(server, p) && !p.isFallFlying();
            Abilities a = p.getAbilities();
            if (ok) {
                boolean changed = false;
                if (!a.mayfly) { a.mayfly = true; changed = true; }
                if (a.getFlyingSpeed() != cfg.flySpeed) { a.setFlyingSpeed(cfg.flySpeed); changed = true; }
                granted.add(p.getUUID());
                if (changed) p.onUpdateAbilities();
            } else if (granted.contains(p.getUUID()) && !p.isFallFlying()) {
                revoke(p);
            }
        }
    }

    private void revoke(ServerPlayer p) {
        if (!granted.remove(p.getUUID())) return;
        Abilities a = p.getAbilities();
        a.mayfly = false;
        a.flying = false;
        a.setFlyingSpeed(0.05f);
        p.onUpdateAbilities();
        p.resetFallDistance();
    }

    private void load() {
        try {
            if (Files.exists(file)) cfg = GSON.fromJson(Files.readString(file), Config.class);
            if (cfg == null) cfg = new Config();
            if (cfg.boxes == null) cfg.boxes = new ArrayList<>();
            if (cfg.teamObjective == null) cfg.teamObjective = "bm_team";
        } catch (Exception e) { cfg = new Config(); }
    }

    private void save() {
        try { Files.writeString(file, GSON.toJson(cfg)); } catch (Exception ignored) {}
    }
}
